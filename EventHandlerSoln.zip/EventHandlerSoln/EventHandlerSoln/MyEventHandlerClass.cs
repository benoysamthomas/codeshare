﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandlerSoln
{
    public class MyEventHandlerClass
    {
     
        public void HandleMyEvent(object sender, MyEventArgs e)
        {
            Console.WriteLine($"Message received: {e.Message}");
        }
    }
}
