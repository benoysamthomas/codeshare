﻿// See https://aka.ms/new-console-template for more information
using EventHandlerSoln;
using System.Reflection.Metadata;

public class Program
{
    public static void Main()
    {
        MyEventSource myEventSource = new MyEventSource();

       
        MyEventHandlerClass myEventHandler = new MyEventHandlerClass();

     
        myEventSource.MyEvent += myEventHandler.HandleMyEvent;

        myEventSource.RaiseEvent("Hello World!");
    }
}






