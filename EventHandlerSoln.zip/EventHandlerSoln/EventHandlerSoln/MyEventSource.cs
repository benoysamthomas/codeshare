﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandlerSoln
{
    public class MyEventSource
    {
      
        public delegate void MyEventHandler(object sender, MyEventArgs e);

      
        public event MyEventHandler MyEvent;

 
        public void RaiseEvent(string message)
        {
           
            if (MyEvent != null)
            {
                
                MyEventArgs args = new MyEventArgs(message);

                MyEvent(this, args);
            }
        }
    }
}
