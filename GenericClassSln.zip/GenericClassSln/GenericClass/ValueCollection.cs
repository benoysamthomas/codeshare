﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericClass
{
    public class ValueCollection<T> where T : struct
    {
        private List<T> items;

        public ValueCollection()
        {
            items = new List<T>();
        }

        public void AddItem(T item)
        {
            items.Add(item);
        }

        public T GetItem(int index)
        {
            return items[index];
        }

        public List<T> GetSortedDescending()
        {
            var sortedList = items.OrderByDescending(i => i).ToList();
            return sortedList;
        }
    }
}
