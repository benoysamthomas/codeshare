﻿// See https://aka.ms/new-console-template for more information
using GenericClass;

class Program
{
    static void Main(string[] args)
    {
       
        var collection = new ValueCollection<int>();

   
        collection.AddItem(10);
        collection.AddItem(5);
        collection.AddItem(15);
        collection.AddItem(3);

        
        int item = collection.GetItem(1);
        Console.WriteLine($"Item at index 1: {item}");

        
        var sortedList = collection.GetSortedDescending();
        Console.WriteLine("Sorted list:");
        foreach (int i in sortedList)
        {
            Console.WriteLine(i);
        }

        Console.ReadLine();
    }
}
